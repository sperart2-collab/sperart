SPERART AI assistant patch

Replace these files in your project:
1. AdminAssistant.tsx -> src/components/AdminAssistant.tsx
2. route.ts -> src/app/api/admin/assistant/route.ts
3. agent.ts -> src/app/admin/agent.ts (unchanged copy; included for reference only)

Changes:
- Restyled the assistant with a dark, polished chat UI.
- Added browser microphone transcription, spoken replies, and a turn-based voice mode.
- Prevented empty AI promises from being presented as completed actions.
- Added a server-side fallback for an explicitly approved publish plan when the model repeats a promise, using exact draft IDs/titles from the database snapshot.

Important:
- Browser speech recognition works best in current Chrome/Edge and requires microphone permission.
- This is turn-based voice conversation, not a true low-latency full-duplex audio model.
- Test locally with npm run build and npm run dev. Do not deploy until you test sign-in, chat, publishing, mic and speech output.
- This patch does not automatically publish anything during installation. It only acts when a user requests/approves it in the admin assistant.
